"""DESC - Deep Embeded Single Cell Clustering 

"""
import os
os.environ['KERAS_BACKEND'] = 'tensorflow'
from .train import train
#load some function 

